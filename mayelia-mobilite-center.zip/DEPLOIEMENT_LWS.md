# 🚀 Guide de Déploiement - Production LWS

## ⚠️ IMPORTANT : Gestion des Assets (CSS/JS)

Laravel utilise **Vite** pour gérer les assets. En production, vous devez utiliser les fichiers **compilés**, pas le serveur de développement.

---

## 📦 Étape 1 : Préparer les fichiers en local

### 1.1 Compiler les assets pour la production
```bash
npm run build
```

✅ Cela crée les fichiers dans `/public/build/`

### 1.2 Vérifier que les fichiers sont générés
Vérifiez que ces fichiers existent :
- `public/build/manifest.json`
- `public/build/assets/app-[hash].css`
- `public/build/assets/app-[hash].js`

### 1.3 Créer l'archive ZIP
Incluez TOUS les fichiers SAUF :
- `node_modules/`
- `vendor/`
- `.env`
- `storage/logs/*.log`

⚠️ **IMPORTANT** : Incluez le dossier `public/build/` avec tous ses fichiers !

---

## 🌐 Étape 2 : Upload sur LWS

### 2.1 Structure des dossiers sur le serveur
```
/home/votre-compte/
├── laravel-app/              # Application Laravel
│   ├── app/
│   ├── config/
│   ├── resources/
│   ├── routes/
│   ├── storage/
│   └── ...
└── public_html/              # Dossier public
    ├── build/                # ⚠️ IMPORTANT : Assets compilés
    │   ├── manifest.json
    │   └── assets/
    ├── index.php
    ├── .htaccess
    └── ...
```

### 2.2 Uploader les fichiers
1. Uploadez l'archive ZIP dans `/home/votre-compte/`
2. Décompressez
3. **Déplacez le contenu de `/public`** vers `/public_html/`
4. **Vérifiez que `/public_html/build/` existe et contient les fichiers**

---

## ⚙️ Étape 3 : Configuration du fichier `.env`

Créez `/home/votre-compte/laravel-app/.env` :

```env
APP_NAME="Mayelia Mobilite Center"
APP_ENV=production
APP_KEY=base64:VOTRE_CLE_GENEREE
APP_DEBUG=false
APP_URL=https://votre-domaine.com

LOG_CHANNEL=stack
LOG_LEVEL=error

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=votre_base
DB_USERNAME=votre_user
DB_PASSWORD=votre_password

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DISK=local
QUEUE_CONNECTION=sync
SESSION_DRIVER=file
SESSION_LIFETIME=120

# ⚠️ IMPORTANT pour les assets
ASSET_URL=https://votre-domaine.com
```

---

## 🔧 Étape 4 : Configuration SSH (si disponible)

```bash
# Se connecter
ssh votre-compte@votre-serveur.lws.fr

# Aller dans le dossier
cd /home/votre-compte/laravel-app

# Installer les dépendances PHP
composer install --no-dev --optimize-autoloader

# Générer la clé d'application
php artisan key:generate

# Exécuter les migrations
php artisan migrate --force

# Créer le lien symbolique
php artisan storage:link

# Nettoyer et optimiser
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

php artisan config:cache
php artisan route:cache
php artisan view:cache

# Permissions
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

---

## 📝 Étape 5 : Modifier `public_html/index.php`

```php
<?php

use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// ⚠️ Modifier ces chemins
require __DIR__.'/../laravel-app/vendor/autoload.php';

$app = require_once __DIR__.'/../laravel-app/bootstrap/app.php';

$kernel = $app->make(Kernel::class);

$response = $kernel->handle(
    $request = Request::capture()
)->send();

$kernel->terminate($request, $response);
```

---

## 🔍 Étape 6 : Vérification

### ✅ Checklist finale :
- [ ] Le fichier `.env` existe avec `APP_ENV=production`
- [ ] Le dossier `/public_html/build/` existe et contient les assets
- [ ] Le fichier `/public_html/build/manifest.json` existe
- [ ] Les permissions sont correctes (775 pour storage et bootstrap/cache)
- [ ] La base de données est configurée et les migrations sont exécutées
- [ ] Le cache est optimisé (`php artisan config:cache`)

### 🧪 Tester :
1. Visitez votre domaine
2. Ouvrez la console du navigateur (F12)
3. Vérifiez qu'il n'y a pas d'erreurs 404 pour les fichiers CSS/JS
4. Les styles doivent s'afficher correctement

---

## 🐛 Troubleshooting

### Problème : Les styles ne s'affichent pas

**Cause** : Les fichiers dans `/public/build/` sont manquants ou mal placés.

**Solution** :
1. Vérifiez que `/public_html/build/manifest.json` existe
2. Vérifiez que les fichiers CSS/JS sont dans `/public_html/build/assets/`
3. Vérifiez le `.env` : `APP_ENV=production` et `ASSET_URL=https://votre-domaine.com`
4. Exécutez : `php artisan config:clear && php artisan config:cache`

### Problème : Erreur 500

**Solution** :
1. Vérifiez les logs : `/home/votre-compte/laravel-app/storage/logs/laravel.log`
2. Vérifiez les permissions : `chmod -R 775 storage bootstrap/cache`
3. Vérifiez le `.env` (surtout `APP_KEY`)

### Problème : Base de données non accessible

**Solution** :
1. Vérifiez les credentials dans `.env`
2. Vérifiez que l'utilisateur MySQL a les permissions sur la base

---

## 🔄 Mise à jour de l'application

Quand vous modifiez le code :

1. **En local** :
   ```bash
   npm run build
   ```

2. **Uploader** uniquement les fichiers modifiés + le dossier `/public/build/`

3. **Sur le serveur** :
   ```bash
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

---

## 📞 Support

En cas de problème, vérifiez :
1. Les logs Laravel : `storage/logs/laravel.log`
2. Les logs Apache/Nginx du serveur
3. La console du navigateur (F12)
