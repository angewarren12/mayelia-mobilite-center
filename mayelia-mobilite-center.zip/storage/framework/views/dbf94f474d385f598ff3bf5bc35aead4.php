<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Mayelia Centers')); ?> - Dashboard</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <!-- Tailwind CSS Local -->
    <script src="<?php echo e(asset('js/tailwind.js')); ?>"></script>
    
    <!-- Font Awesome Local -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.css')); ?>">
    
    <!-- Tailwind Config -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    animation: {
                        'page-enter': 'pageEnter 0.4s ease-out forwards',
                    },
                    keyframes: {
                        pageEnter: {
                            '0%': { opacity: '0', transform: 'translateY(10px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' },
                        }
                    },
                    colors: {
                        'mayelia': {
                            50: '#f2faf5',
                            100: '#e6f4ec',
                            200: '#c0e4cf',
                            300: '#9ad3b2',
                            400: '#4eb279',
                            500: '#02913F',
                            600: '#028339',
                            700: '#01662c',
                            800: '#014920',
                            900: '#012c13',
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Alpine.js for dropdowns -->
    <script defer src="<?php echo e(asset('js/alpine.js')); ?>"></script>
</head>
<body class="font-sans antialiased bg-gray-100" x-data="{ 
    sidebarOpen: window.innerWidth >= 1024 ? (localStorage.getItem('sidebarOpen') !== 'false') : false,
    mobileOpen: false 
}" 
      x-init="$watch('sidebarOpen', value => { if(window.innerWidth >= 1024) localStorage.setItem('sidebarOpen', value) });">
    <div class="min-h-screen flex">
        <!-- Mobile Sidebar Overlay -->
        <div x-show="sidebarOpen && window.innerWidth < 1024" 
             @click="sidebarOpen = false"
             x-transition:enter="transition-opacity ease-linear duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition-opacity ease-linear duration-300"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0"
             class="fixed inset-0 bg-gray-600 bg-opacity-75 z-40 lg:hidden"></div>

        <!-- Sidebar -->
        <div class="bg-gradient-to-b from-mayelia-600 to-mayelia-800 shadow-lg flex flex-col transition-all duration-300 ease-in-out fixed lg:static inset-y-0 left-0 z-50 min-h-screen"
             :class="sidebarOpen ? 'w-64 translate-x-0' : '-translate-x-full lg:translate-x-0 w-64 lg:w-20'">
            <div class="p-6 flex justify-center items-center border-b border-gray-200 bg-white relative">
                <img src="<?php echo e(asset('img/logo-oneci.jpg')); ?>" alt="Mayelia Mobilité" 
                     class="h-16 w-auto transition-all duration-300"
                     :class="sidebarOpen ? 'opacity-100 block' : 'opacity-0 w-0 h-0 hidden'">
                <img src="<?php echo e(asset('img/logo-oneci.jpg')); ?>" alt="Mayelia Mobilité" 
                     class="h-10 w-10 rounded transition-all duration-300 object-cover"
                     :class="sidebarOpen ? 'opacity-0 w-0 h-0 hidden' : 'opacity-100 block'">
            </div>
            
            <nav class="mt-6 flex-1 overflow-y-auto">
                <?php
                    $authService = app(\App\Services\AuthService::class);
                ?>
                
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center px-6 py-3 group <?php echo e(request()->routeIs('dashboard') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Tableau de bord' : ''">
                    <i class="fas fa-home w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Tableau de bord</span>
                </a>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('centres', 'view')): ?>
                <a href="<?php echo e(route('centres.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('centres.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Gestion du centre' : ''">
                    <i class="fas fa-building w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Gestion du centre</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('creneaux', 'view')): ?>
                <a href="<?php echo e(route('creneaux.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('creneaux.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Gestion des créneaux' : ''">
                    <i class="fas fa-calendar-alt w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Gestion des créneaux</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('clients', 'view')): ?>
                <a href="<?php echo e(route('clients.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('clients.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Clients' : ''">
                    <i class="fas fa-users w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Clients</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('rendez-vous', 'view')): ?>
                <a href="<?php echo e(route('rendez-vous.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('rendez-vous.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Rendez-vous' : ''">
                    <i class="fas fa-calendar-check w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Rendez-vous</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || in_array($authService->getAuthenticatedUser()->role, ['agent', 'agent_biometrie'])): ?>
                <a href="<?php echo e(route('qms.agent')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('qms.agent') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Guichet Agent' : ''">
                    <i class="fas fa-desktop w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Guichet Agent</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin()): ?>
                <a href="<?php echo e(route('agents.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('agents.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Agents' : ''">
                    <i class="fas fa-user-tie w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Agents</span>
                </a>
                
                <a href="<?php echo e(route('admin.guichets.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('admin.guichets.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Guichets' : ''">
                    <i class="fas fa-columns w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Gestion des Guichets</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('dossiers', 'view')): ?>
                <a href="<?php echo e(route('dossiers.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('dossiers.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Dossiers' : ''">
                    <i class="fas fa-folder-open w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Dossiers</span>
                </a>
                <?php endif; ?>

                <?php if($authService->isAdmin() || in_array($authService->getAuthenticatedUser()->role, ['agent', 'agent_biometrie'])): ?>
                <a href="<?php echo e(route('retraits.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('retraits.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Retraits de carte' : ''">
                    <i class="fas fa-id-card w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Retraits de carte</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin() || $authService->hasPermission('statistics', 'view')): ?>
                <a href="<?php echo e(route('statistics.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('statistics.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Statistiques' : ''">
                    <i class="fas fa-chart-line w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Statistiques</span>
                </a>
                <?php endif; ?>
                
                <?php if($authService->isAdmin()): ?>
                <a href="<?php echo e(route('document-requis.index')); ?>" class="flex items-center px-6 py-3 <?php echo e(request()->routeIs('document-requis.*') ? 'bg-white text-mayelia-700 border-r-4 border-mayelia-900 font-semibold' : 'text-white/90 hover:bg-white/10 hover:text-white transition-colors'); ?>"
                   :title="!sidebarOpen ? 'Documents requis' : ''">
                    <i class="fas fa-file-alt w-5 h-5" :class="sidebarOpen ? 'mr-3' : 'mx-auto'"></i>
                    <span class="transition-opacity duration-300 whitespace-nowrap" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0 overflow-hidden'">Documents requis</span>
                </a>
                <?php endif; ?>

                
            </nav>
            
            <div class="p-4 border-t border-white/10">
                <div class="flex items-center justify-between text-white/90">
                    <?php
                        $currentUser = $authService->getAuthenticatedUser();
                        $userName = $currentUser ? ($currentUser instanceof \App\Models\Agent ? $currentUser->nom_complet : $currentUser->nom) : 'Utilisateur';
                    ?>
                    <div class="flex items-center" :class="sidebarOpen ? 'flex-row' : 'flex-col'">
                        <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center" :class="sidebarOpen ? 'mr-2' : 'mx-auto mb-2'">
                            <i class="fas fa-user text-xs"></i>
                        </div>
                        <span class="text-sm font-medium transition-opacity duration-300 whitespace-nowrap" 
                              :class="sidebarOpen ? 'opacity-100 truncate max-w-[100px]' : 'opacity-0 w-0 overflow-hidden'"><?php echo e($userName); ?></span>
                    </div>
                    <div class="flex items-center" :class="sidebarOpen ? '' : 'ml-auto'">
                        <a href="<?php echo e(route('profile.edit')); ?>" class="text-white/70 hover:text-white transition-colors p-1 rounded hover:bg-white/10 mr-1" title="Paramètres">
                            <i class="fas fa-cog"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-white/70 hover:text-white transition-colors p-1 rounded hover:bg-white/10" title="Déconnexion">
                            <i class="fas fa-sign-out-alt"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b">
                <div class="px-6 py-4">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <button @click="sidebarOpen = !sidebarOpen" 
                                    class="p-2 rounded-md text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                                    :title="sidebarOpen ? 'Masquer la sidebar' : 'Afficher la sidebar'">
                                <i class="fas" :class="sidebarOpen ? 'fa-chevron-left' : 'fa-chevron-right'"></i>
                            </button>
                        </div>
                        <div class="flex items-center space-x-4">
                            <?php
                                $currentUser = $authService->getAuthenticatedUser();
                                $nomComplet = $currentUser ? trim(($currentUser->nom ?? '') . ' ' . ($currentUser->prenom ?? '')) : 'Utilisateur';
                                $role = $currentUser ? match($currentUser->role) {
                                    'admin' => 'Administrateur',
                                    'agent' => 'Agent',
                                    'agent_biometrie' => 'Agent Biométrie',
                                    'oneci' => 'Agent ONECI',
                                    default => 'Utilisateur'
                                } : '';
                                $roleColor = $currentUser ? match($currentUser->role) {
                                    'admin' => 'bg-mayelia-100 text-mayelia-800',
                                    'oneci' => 'bg-purple-100 text-purple-800',
                                    'agent_biometrie' => 'bg-blue-100 text-blue-800',
                                    default => 'bg-green-100 text-green-800'
                                } : '';
                            ?>
                            
                            <?php if($currentUser): ?>
                            <!-- Notifications -->
                            <?php if(in_array($currentUser->role, ['admin', 'agent'])): ?>
                                <?php echo $__env->make('components.notifications', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                            
                            <div class="flex items-center space-x-3">
                                <div class="text-right">
                                    <div class="text-sm font-semibold text-gray-900"><?php echo e($nomComplet); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo e($role); ?></div>
                                </div>
                                <div class="w-10 h-10 rounded-full <?php echo e($roleColor); ?> flex items-center justify-center">
                                    <i class="fas <?php echo e(match($currentUser->role) {
                                        'admin' => 'fa-user-shield',
                                        'oneci' => 'fa-building',
                                        default => 'fa-user-tie'
                                    }); ?> text-sm"></i>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php echo $__env->yieldContent('header-actions'); ?>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <main class="flex-1 p-6 animate-page-enter">
                <!-- Page Title -->
                <?php if (! empty(trim($__env->yieldContent('title')))): ?>
                    <div class="mb-6 pb-4 border-b border-gray-200">
                        <h1 class="text-2xl font-bold text-mayelia-600"><?php echo $__env->yieldContent('title'); ?></h1>
                        <?php if (! empty(trim($__env->yieldContent('subtitle')))): ?>
                            <p class="text-gray-600 mt-1"><?php echo $__env->yieldContent('subtitle'); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <!-- Toast Notifications -->
    <?php echo $__env->make('components.toast', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if(session('success')): ?>
                showSuccessToast(<?php echo json_encode(session('success'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('error')): ?>
                showErrorToast(<?php echo json_encode(session('error'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('warning')): ?>
                showWarningToast(<?php echo json_encode(session('warning'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('info')): ?>
                showInfoToast(<?php echo json_encode(session('info'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('status') === 'password-updated'): ?>
                showSuccessToast("Mot de passe mis à jour avec succès.");
            <?php elseif(session('status') === 'profile-updated'): ?>
                showSuccessToast("Profil mis à jour avec succès.");
            <?php elseif(session('status') === 'verification-link-sent'): ?>
                showInfoToast("Un nouveau lien de vérification a été envoyé à votre adresse email.");
            <?php elseif(session('status')): ?>
                showInfoToast(<?php echo json_encode(session('status'), 15, 512) ?>);
            <?php endif; ?>
        });
    </script>

    <!-- Global QMS Widget -->
    <?php echo $__env->make('partials.qms-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\ThinkPad\mayelia-mobilite-center\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>