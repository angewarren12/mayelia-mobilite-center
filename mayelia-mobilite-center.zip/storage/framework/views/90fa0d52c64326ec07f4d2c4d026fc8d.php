﻿

<?php $__env->startSection('title', $title ?? 'Gestion des Créneaux'); ?>
<?php $__env->startSection('subtitle', $subtitle ?? 'Gérez les jours de travail, les templates et les exceptions'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Onglets de navigation -->
    <div class="bg-white rounded-lg shadow">
        <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8 px-6" aria-label="Tabs">
                <a href="<?php echo e(route('creneaux.index')); ?>" 
                   class="py-4 px-1 border-b-2 font-medium text-sm <?php echo e(request()->routeIs('creneaux.index') ? 'border-mayelia-500 text-mayelia-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <i class="fas fa-calendar-day mr-2"></i>
                    Jours ouvrables
                </a>
                <a href="<?php echo e(route('creneaux.templates')); ?>" 
                   class="py-4 px-1 border-b-2 font-medium text-sm <?php echo e(request()->routeIs('creneaux.templates') ? 'border-mayelia-500 text-mayelia-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <i class="fas fa-calendar-alt mr-2"></i>
                    Templates
                </a>
                <a href="<?php echo e(route('creneaux.exceptions')); ?>" 
                   class="py-4 px-1 border-b-2 font-medium text-sm <?php echo e(request()->routeIs('creneaux.exceptions') ? 'border-mayelia-500 text-mayelia-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Exceptions
                </a>
                <a href="<?php echo e(route('creneaux.calendrier')); ?>" 
                   class="py-4 px-1 border-b-2 font-medium text-sm <?php echo e(request()->routeIs('creneaux.calendrier') ? 'border-mayelia-500 text-mayelia-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'); ?>">
                    <i class="fas fa-calendar mr-2"></i>
                    Calendrier
                </a>
            </nav>
        </div>
    </div>

    <!-- Contenu spécifique à chaque page -->
    <?php echo $__env->yieldContent('creneaux_content'); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ThinkPad\mayelia-mobilite-center\resources\views/creneaux/layout.blade.php ENDPATH**/ ?>