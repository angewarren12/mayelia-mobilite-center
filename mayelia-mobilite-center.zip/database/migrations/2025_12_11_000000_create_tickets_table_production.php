<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Créer la table tickets SANS contraintes FK (pour éviter problèmes d'ordre)
        if (!Schema::hasTable('tickets')) {
            Schema::create('tickets', function (Blueprint $table) {
                $table->id();
                $table->string('numero')->unique();
                $table->unsignedBigInteger('centre_id');
                $table->unsignedBigInteger('service_id')->nullable();
                $table->unsignedBigInteger('user_id')->nullable();
                $table->unsignedBigInteger('guichet_id')->nullable();
                $table->enum('statut', ['en_attente', 'appelé', 'en_cours', 'terminé', 'absent', 'annulé'])
                    ->default('en_attente');
                $table->enum('type', ['rdv', 'sans_rdv'])->default('sans_rdv');
                $table->time('heure_rdv')->nullable();
                $table->integer('priorite')->default(1);
                $table->timestamp('called_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                
                // Index pour performance (pas de FK pour l'instant)
                $table->index(['centre_id', 'statut']);
                $table->index('guichet_id');
                $table->index('service_id');
                $table->index('created_at');
            });
        }
        
        // Ajouter la colonne heure_rdv si elle n'existe pas déjà
        if (Schema::hasTable('tickets') && !Schema::hasColumn('tickets', 'heure_rdv')) {
            Schema::table('tickets', function (Blueprint $table) {
                $table->time('heure_rdv')->nullable()->after('type');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
